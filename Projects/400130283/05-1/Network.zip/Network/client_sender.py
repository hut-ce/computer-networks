import socket
import threading
import json
import random

HOST = '127.0.0.1'
PORT = 12345

def receive_messages(client_socket):
    try:
        while True:
            message = client_socket.recv(1024)
            if not message:
                print("Server closed the connection.")
                break

            data = message.decode("utf-8")
            print(f"Message from server: {data}")
    except Exception as e:
        print(f"Error receiving message: {e}")
    finally:
        client_socket.close()

def main():
    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect((HOST, PORT))
        print("Connected to the server.")

        client_socket.send("SENDER".encode("utf-8"))

        threading.Thread(target=receive_messages, args=(client_socket,), daemon=True).start()

        while True:
            try:
                counter = int(input("Enter number of elements: "))
                array = []
                for i in range(counter):
                    element = int(input(f"Enter element {i + 1}: "))
                    array.append(element)

                print(f"Array to send: {array}")
                to_send = json.dumps(array)
                client_socket.send(to_send.encode("utf-8"))
            except ValueError:
                print("Invalid input. Please enter integers only.")
            except KeyboardInterrupt:
                print("\nExiting...")
                break

    except ConnectionRefusedError:
        print("Failed to connect to the server. Is the server running?")
    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        client_socket.close()
        print("Connection closed.")

if __name__ == "__main__":
    main()
