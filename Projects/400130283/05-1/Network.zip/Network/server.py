import socket
import threading
import json
import time

HOST = '127.0.0.1'
PORT = 12345

clients = {} 
sender_socket = None
lock = threading.Lock()

sorting_times = {}


def handle_client(client_socket, addr):
    global sender_socket
    try:
        print(f"Client {addr} connected.")
        role = None

        while True:
            message = client_socket.recv(1024)
            if not message:
                print(f"Client {addr} disconnected.")
                break

            data = message.decode("utf-8")

            if role is None:
                if data == "SENDER":
                    role = "SENDER"
                    with lock:
                        sender_socket = client_socket
                    clients[client_socket] = role
                    print(f"Client {addr} identified as SENDER.")
                elif data == "SORTER":
                    role = "SORTER"
                    with lock:
                        clients[client_socket] = role
                    print(f"Client {addr} identified as SORTER.")
                else:
                    print(f"Unknown role from client {addr}. Disconnecting...")
                    break
                continue

            if role == "SENDER":
                array = json.loads(data)
                print(f"Array received from sender: {array}")
                broadcast_to_sorters(array)

            elif role == "SORTER":
                end_time = time.time()
                sorted_array = json.loads(data)

                with lock:
                    sorting_times[client_socket] = end_time - sorting_times.get(client_socket, end_time)

                print(f"Sorted array received from sorter {addr}: {sorted_array} (Time: {sorting_times[client_socket]:.4f}s)")
                send_to_sender(sorted_array, addr)

    except Exception as e:
        print(f"Error with client {addr}: {e}")
    finally:
        with lock:
            if client_socket in clients:
                del clients[client_socket]
            if client_socket == sender_socket:
                sender_socket = None
            if client_socket in sorting_times:
                del sorting_times[client_socket]
        client_socket.close()


def broadcast_to_sorters(array):
    with lock:
        for client_socket, role in clients.items():
            if role == "SORTER":
                try:
                    sorting_times[client_socket] = time.time() 
                    client_socket.send(json.dumps(array).encode("utf-8"))
                except Exception as e:
                    print(f"Error sending to sorter: {e}")


def send_to_sender(sorted_array, sorter_addr):
    with lock:
        if sender_socket:
            try:
                sorter_socket = None
                for client_socket, role in clients.items():
                    if role == "SORTER" and client_socket.getpeername() == sorter_addr:
                        sorter_socket = client_socket
                        break

                elapsed_time = sorting_times.get(sorter_socket, "N/A")

                message = {
                    "sorted_array": sorted_array,
                    "sorter": f"{sorter_addr[0]}:{sorter_addr[1]}",
                    "time": f"{elapsed_time:.4f}s" if isinstance(elapsed_time, float) else "N/A"
                }
                sender_socket.send(json.dumps(message).encode("utf-8"))
                print(f"Sent sorted array to sender: {sorted_array}")
            except Exception as e:
                print(f"Error sending to sender: {e}")

def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen(5)
    print(f"Server started on {HOST}:{PORT}, waiting for connections...")

    try:
        while True:
            client_socket, addr = server.accept()
            threading.Thread(target=handle_client, args=(client_socket, addr), daemon=True).start()
    except KeyboardInterrupt:
        print("\nShutting down server.")
    finally:
        server.close()


if __name__ == "__main__":
    main()
