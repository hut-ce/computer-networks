import socket
import threading
import json
import time

HOST = '127.0.0.1'
PORT = 12345

def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        if not swapped:
            break
    return arr

def handle_server(client_socket):
    while True:
        try:
            message = client_socket.recv(1024)
            if not message:
                print("Disconnected from server.")
                break

            array = json.loads(message.decode("utf-8"))
            print(f"Received array to sort (Bubble): {array}")

            sort_start = time.perf_counter()
            sorted_array = bubble_sort(array)
            sort_end = time.perf_counter()
            sort_time = sort_end - sort_start
            print(sort_time)
            print(f"Sorted array (Bubble): {sorted_array}")

            client_socket.send(json.dumps(sorted_array).encode("utf-8"))

        except Exception as e:
            print(f"Error: {e}")
            break

def main():
    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect((HOST, PORT))
        print("Connected to the server.")

        client_socket.send("SORTER".encode("utf-8"))

        handle_server(client_socket)

    except Exception as e:
        print(f"Connection error: {e}")
    finally:
        client_socket.close()

if __name__ == "__main__":
    main()
