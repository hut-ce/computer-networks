import socket
import ssl

def run_client(host='localhost', port=12345):
    """اجرای کلاینت با اتصال SSL"""
    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        with ssl.wrap_socket(client_socket, keyfile=None, certfile=None, server_side=False, server_hostname=host) as secure_socket:
            secure_socket.connect((host, port))

            data = secure_socket.recv(1024)
            print(f"Received from server: {data.decode('utf-8')}")

            message = input("Enter your message: ")
            secure_socket.send(message.encode('utf-8'))

    except ssl.SSLError as e:
        print(f"SSL error occurred: {e}")
    except socket.error as e:
        print(f"Socket error occurred: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    run_client()
