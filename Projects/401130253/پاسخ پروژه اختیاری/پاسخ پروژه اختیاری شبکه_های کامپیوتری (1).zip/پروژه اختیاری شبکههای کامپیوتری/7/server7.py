import socket
import ssl

def run_server(host='localhost', port=12345):
    """اجرای سرور با SSL"""
    try:
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind((host, port))

        server_socket.listen(5)
        print("Server is listening for connections...")

        with ssl.wrap_socket(server_socket, keyfile="server-key.pem", certfile="server-cert.pem", server_side=True) as secure_socket:
            while True:
                client_socket, client_address = secure_socket.accept()
                print(f"Connection from {client_address} has been established!")

                client_socket.send(b"Welcome to the secure chat room!")
                data = client_socket.recv(1024)
                print(f"Received message: {data.decode('utf-8')}")

                client_socket.close()
    
    except ssl.SSLError as e:
        print(f"SSL error occurred: {e}")
    except socket.error as e:
        print(f"Socket error occurred: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    run_server()
