import socket

def run_client(domain_name, dns_server_address=('localhost', 53)):
    """اجرای کلاینت برای درخواست DNS"""
    try:
        # ایجاد سوکت UDP برای ارتباط با سرور
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client_socket:
            # ارسال درخواست به سرور DNS
            client_socket.sendto(domain_name.encode('utf-8'), dns_server_address)

            # دریافت پاسخ از سرور DNS
            data, server_address = client_socket.recvfrom(512)

            # نمایش IP دریافت شده
            print(f"The IP address for {domain_name} is: {data.decode('utf-8')}")

    except socket.error as e:
        print(f"Socket error occurred: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    domain_name = input("Enter domain name (e.g., google.com): ")
    run_client(domain_name)
