import socket

def execute_client(server_address='127.0.0.1', server_port=12345):
    client_conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_conn.connect((server_address, server_port))
    print(client_conn.recv(1024).decode())

    while True:
        user_command = input("Enter command (SET/GET/DEL/SHOW/EXIT): ")
        client_conn.send(user_command.encode())

        if user_command.upper() == 'EXIT':
            print("Terminating connection...")
            break

        server_reply = client_conn.recv(4096).decode()
        print(f"Server reply:\n{server_reply}")

    client_conn.close()

if __name__ == "__main__":
    execute_client()
