import socket
import threading

key_value_store = {}
lock = threading.Lock()

def handle_client(connection, address):
    """مدیریت درخواست‌های کلاینت"""
    print(f"New connection from {address}")
    connection.send("Welcome to the key-value server!\nUse SET/GET/DEL/SHOW/EXIT.".encode())

    while True:
        try:
            command = connection.recv(1024).decode().strip()
            if not command:
                continue

            parts = command.split()
            if len(parts) == 0:
                connection.send("Invalid command format.".encode())
                continue

            action = parts[0].upper()

            with lock:
                if action == 'SET' and len(parts) == 3:
                    key, value = parts[1], parts[2]
                    key_value_store[key] = value
                    connection.send(f"Key '{key}' set to '{value}'.".encode())

                elif action == 'GET' and len(parts) == 2:
                    key = parts[1]
                    value = key_value_store.get(key, "Key not found.")
                    connection.send(f"{key}: {value}".encode())

                elif action == 'DEL' and len(parts) == 2:
                    key = parts[1]
                    if key in key_value_store:
                        del key_value_store[key]
                        connection.send(f"Key '{key}' deleted.".encode())
                    else:
                        connection.send("Key not found.".encode())

                elif action == 'SHOW':
                    all_data = "\n".join([f"{k}: {v}" for k, v in key_value_store.items()]) or "Database is empty."
                    connection.send(all_data.encode())

                elif action == 'EXIT':
                    connection.send("Goodbye!".encode())
                    break

                else:
                    connection.send("Invalid command. Use SET/GET/DEL/SHOW/EXIT.".encode())

        except Exception as e:
            connection.send(f"Error: {e}".encode())

    connection.close()

def run_server(host='127.0.0.1', port=12345):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(5)
    print(f"Key-Value server active at {host}:{port}")

    while True:
        conn, addr = server_socket.accept()
        threading.Thread(target=handle_client, args=(conn, addr)).start()

if __name__ == "__main__":
    run_server()
