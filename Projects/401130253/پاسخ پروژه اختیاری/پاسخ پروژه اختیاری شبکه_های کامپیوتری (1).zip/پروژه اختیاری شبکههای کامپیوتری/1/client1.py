from ftplib import FTP

def send_file():
    # اتصال به سرور FTP
    ftp_conn = FTP()
    ftp_conn.connect("127.0.0.1", 2121)
    ftp_conn.login("user", "12345")

    # ارسال فایل به سرور
    file_name = "test.txt"
    with open(file_name, "rb") as file_obj:
        ftp_conn.storbinary(f"STOR {file_name}", file_obj)

    print(f"{file_name} has been sent successfully.")
    ftp_conn.quit()

def receive_file():
    # اتصال مجدد به سرور FTP
    ftp_conn = FTP()
    ftp_conn.connect("127.0.0.1", 2121)
    ftp_conn.login("user", "12345")

    # دریافت فایل از سرور
    file_name = "test.txt"
    with open(f"received_{file_name}", "wb") as file_obj:
        ftp_conn.retrbinary(f"RETR {file_name}", file_obj.write)

    print(f"{file_name} has been received successfully.")
    ftp_conn.quit()

if __name__ == "__main__":
    send_file()
    receive_file()
