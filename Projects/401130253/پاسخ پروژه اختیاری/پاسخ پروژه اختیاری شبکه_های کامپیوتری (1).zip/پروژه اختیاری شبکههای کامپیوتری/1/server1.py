from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer

def initialize_ftp_service():
    # ایجاد مجوزدهنده برای کاربران
    permission_manager = DummyAuthorizer()
    
    # افزودن کاربر با دسترسی کامل
    permission_manager.add_user("user", "12345", ".", perm="elradfmw")

    # تنظیم هندلر مدیریت ارتباطات
    connection_handler = FTPHandler
    connection_handler.authorizer = permission_manager

    # راه‌اندازی سرور FTP روی پورت مشخص
    ftp_service = FTPServer(("0.0.0.0", 2121), connection_handler)
    
    print("FTP server is now active on port 2121...")
    ftp_service.serve_forever()

if __name__ == "__main__":
    initialize_ftp_service()
