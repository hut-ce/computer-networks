import socket
import random
import time
import threading

currency_rates = {
    'USD': 100.0,
    'EUR': 120.0,
    'JPY': 90.0
}

def simulate_price_updates():
    """ شبیه‌سازی به‌روزرسانی تصادفی قیمت ارزها """
    while True:
        for currency in currency_rates:
            fluctuation = random.uniform(-0.5, 0.5)
            currency_rates[currency] += fluctuation
        time.sleep(2)

def client_handler(client_connection, client_address):
    """ مدیریت درخواست‌های کلاینت """
    print(f"New connection from {client_address}")
    client_connection.send("Welcome to the currency server!\nType 'prices' for rates or 'exit' to quit.".encode())

    while True:
        client_request = client_connection.recv(1024).decode().strip()
        if not client_request:
            continue

        if client_request.lower() == 'exit':
            print(f"Connection closed for {client_address}")
            break
        elif client_request.lower() == 'prices':
            response_data = "\n".join([f"{currency}: {rate:.2f}" for currency, rate in currency_rates.items()])
            client_connection.send(response_data.encode())
        else:
            client_connection.send("Unknown command. Use 'prices' or 'exit'.".encode())

    client_connection.close()

def launch_server(server_host='127.0.0.1', server_port=12345):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((server_host, server_port))
    server.listen(5)
    print(f"Currency server active at {server_host}:{server_port}.")

    threading.Thread(target=simulate_price_updates, daemon=True).start()

    while True:
        conn, addr = server.accept()
        threading.Thread(target=client_handler, args=(conn, addr)).start()

if __name__ == "__main__":
    launch_server()
