import socket

# تنظیمات سرور
SERVER_HOST = 'localhost'
SERVER_PORT = 12345

# ایجاد سوکت و اتصال به سرور
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
    client_socket.connect((SERVER_HOST, SERVER_PORT))
    print("Connected to the server!")

    # دریافت پیام از سرور و انجام حرکت
    while True:
        data = client_socket.recv(1024).decode()
        print(data)
        if "Game Over" in data:
            break

        # گرفتن حرکت از کاربر
        move = input("Enter your move (row,col): ")
        client_socket.send(move.encode())
