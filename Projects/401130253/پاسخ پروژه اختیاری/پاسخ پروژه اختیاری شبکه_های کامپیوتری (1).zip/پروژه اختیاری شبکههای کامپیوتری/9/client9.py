import socket
import time

DHCP_SERVER_ADDRESS = ('localhost', 67)
CLIENT_PORT = 68

client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
client_socket.bind(('localhost', CLIENT_PORT))
client_socket.settimeout(5)  

discover_message = "DHCPDISCOVER"
client_socket.sendto(discover_message.encode('utf-8'), DHCP_SERVER_ADDRESS)
print("Sent DHCPDISCOVER to server")

try:
    data, server_address = client_socket.recvfrom(1024)
    offer_message = data.decode('utf-8')
    print(f"Received DHCPOFFER: {offer_message} from server")

    request_message = f"DHCPREQUEST {offer_message.split()[1]}"
    client_socket.sendto(request_message.encode('utf-8'), DHCP_SERVER_ADDRESS)
    print(f"Sent DHCPREQUEST to server for IP {offer_message.split()[1]}")

    data, server_address = client_socket.recvfrom(1024)
    ack_message = data.decode('utf-8')
    print(f"Received DHCPACK: {ack_message} from server")

except socket.timeout:
    print("No response from DHCP server. The request timed out.")
except Exception as e:
    print(f"An error occurred: {e}")
finally:
    client_socket.close()
