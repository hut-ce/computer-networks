import socket
import subprocess

def initiate_server(host_address='127.0.0.1', server_port=12345):
    srv_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv_socket.bind((host_address, server_port))
    srv_socket.listen(1)
    print(f"Server is now active on {host_address}:{server_port}...")

    connection, client_address = srv_socket.accept()
    print(f"Connection established with {client_address}")

    while True:
        client_command = connection.recv(1024).decode()
        if client_command.lower() == 'exit':
            print("Terminating connection...")
            break

        print(f"Command received: {client_command}")

        try:
            execution_result = subprocess.check_output(client_command, shell=True, stderr=subprocess.STDOUT, text=True)
        except subprocess.CalledProcessError as error:
            execution_result = f"Error: {error.output}"

        connection.send(execution_result.encode())

    connection.close()
    srv_socket.close()

if __name__ == "__main__":
    initiate_server()
