import socket

def initiate_client(server_ip='127.0.0.1', server_port=12345):
    client_conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_conn.connect((server_ip, server_port))
    print("Successfully connected to the server.")

    while True:
        user_input = input("Enter command (type 'exit' to disconnect): ")
        client_conn.send(user_input.encode())

        if user_input.lower() == 'exit':
            print("Disconnecting from the server...")
            break

        server_response = client_conn.recv(4096).decode()
        print(f"Server Response:\n{server_response}")

    client_conn.close()

if __name__ == "__main__":
    initiate_client()
