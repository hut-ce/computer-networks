1. run "server1.py"
2. run "so_runner.py"
3. run "client1.py"
4. enter array in "client.py"
