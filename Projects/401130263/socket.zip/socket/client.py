import socket

def client():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(("127.0.0.1", 12345))

    try:
        #input arrays
        arr = input("Enter an array of integers (comma-separated): ")
        client_socket.send(arr.encode())

        #result
        response = client_socket.recv(4096).decode()
        print("Server response:")
        print(response)

    except Exception as e:
        print(f"Error: {str(e)}")

    finally:
        client_socket.close()

if __name__ == "__main__":
    client()