import socket
import threading
import time
import random

#sorting algorithms
def bubble_sort(arr):
    arr = arr.copy()
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
    return arr

def stalin_sort(arr):
    sorted_list = [arr[0]]
    for i in range(1, len(arr)):
        if arr[i] >= sorted_list[-1]:
            sorted_list.append(arr[i])
    return sorted_list

def is_sorted(arr):
    return all(arr[i] <= arr[i+1] for i in range(len(arr) - 1))

def bogo_sort(arr):
    arr = arr.copy()
    while not is_sorted(arr):
        random.shuffle(arr)
    return arr

#so
def process_array(algorithm, arr, result_dict, algo_name):
    start_time = time.time()
    sorted_arr = algorithm(arr)
    elapsed_time = time.time() - start_time
    result_dict[algo_name] = (sorted_arr, elapsed_time)

# server
def handle_client(client_socket):
    try:
        # receiving arrays
        data = client_socket.recv(1024).decode()
        arr = list(map(int, data.split(',')))
        print(f"Received array: {arr}")

        # calculating arrays
        result = {}
        threads = []
        algorithms = {
            "Bubble Sort": bubble_sort,
            "Stalin Sort": stalin_sort,
            "Bogo Sort": bogo_sort
        }

        for algo_name, algo_func in algorithms.items():
            thread = threading.Thread(target=process_array, args=(algo_func, arr, result, algo_name))
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()

        # finding the fastest algorithm
        fastest_algo = min(result.items(), key=lambda x: x[1][1])[0]

        # sending back to clients
        response = f"Results: {result}\nFastest Algorithm: {fastest_algo}"
        client_socket.send(response.encode())

    except Exception as e:
        client_socket.send(f"Error: {str(e)}".encode())

    finally:
        client_socket.close()

def server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("0.0.0.0", 12345))
    server_socket.listen(5)
    print("Server is running...")

    while True:
        client_socket, addr = server_socket.accept()
        print(f"Connection from {addr}")
        threading.Thread(target=handle_client, args=(client_socket,)).start()

if __name__ == "__main__":
    server()