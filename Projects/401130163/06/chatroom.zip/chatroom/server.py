import socket
import threading

ip = '127.0.0.5'
port = 5050

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((ip, port))
server.listen(5)

print("Server is running and waiting for connections...")

clients = {}
roles = {}
block_lists = {}

ADMIN = "Admin"
MODERATOR = "Moderator"
USER = "User"

banned_words = ["badword1", "badword2", "badword3"]

def filter_message(message):
    for word in banned_words:
        if word in message:
            message = message.replace(word, "*" * len(word))
    return message

def broadcast(message, sender=None):
    for name, conn in clients.items():
        if conn != sender:
            conn.send(message.encode())

def handle_client(connection, address):
    connection.send("Please enter your name:".encode())
    name = connection.recv(1024).decode()
    clients[name] = connection
    block_lists[name] = set()

    roles[name] = ADMIN if len(clients) == 1 else USER
    print(f"{name} ({address}) has joined the chat with role {roles[name]}!")

    broadcast(f"{name} has joined the chat as {roles[name]}.")

    while True:
        try:
            message = connection.recv(1024).decode()

            if not message:
                break

            if message.startswith("/role "):
                if roles[name] == ADMIN:
                    parts = message.split()
                    if len(parts) == 3:
                        target = parts[1]
                        new_role = parts[2]
                        if target in roles and new_role in [ADMIN, MODERATOR, USER]:
                            roles[target] = new_role
                            connection.send(f"{target}'s role changed to {new_role}.".encode())
                            clients[target].send(f"Your role has been changed to {new_role}.".encode())
                        else:
                            connection.send("Invalid role or user.".encode())
                    else:
                        connection.send("Invalid command format. Use /role <username> <role>".encode())
                else:
                    connection.send("You don't have permission to change roles.".encode())

            elif message.startswith("/kick "):
                if roles[name] in [ADMIN, MODERATOR]:
                    target = message.split()[1]
                    if target in clients:
                        clients[target].send("You have been kicked from the chat.".encode())
                        clients[target].close()
                        del clients[target]
                        del roles[target]
                        del block_lists[target]
                        broadcast(f"{target} has been kicked from the chat.")
                    else:
                        connection.send("User not found.".encode())
                else:
                    connection.send("You don't have permission to kick users.".encode())

            elif message.startswith("block "):
                target = message.split(" ", 1)[1]
                if target in clients:
                    block_lists[name].add(target)
                    connection.send(f"You have blocked {target}.".encode())
                else:
                    connection.send(f"User {target} not found.".encode())

            elif message.startswith("unblock "):
                target = message.split(" ", 1)[1]
                if target in block_lists[name]:
                    block_lists[name].remove(target)
                    connection.send(f"You have unblocked {target}.".encode())
                else:
                    connection.send(f"User {target} is not in your block list.".encode())

            elif message.startswith("@"):
                parts = message.split(' ', 1)
                if len(parts) > 1:
                    target_name = parts[0][1:]
                    private_message = filter_message(parts[1])
                    if target_name in clients:
                        if name not in block_lists[target_name]:
                            clients[target_name].send(f"Private message from {name}: {private_message}".encode())
                        else:
                            connection.send(f"You are blocked by {target_name}.".encode())
                    else:
                        connection.send(f"User {target_name} not found.".encode())
                else:
                    connection.send("Invalid private message format!".encode())

            else:
                filtered_message = filter_message(message)
                broadcast(f"{name}: {filtered_message}", sender=connection)
        except ConnectionResetError:
            break

    del clients[name]
    del roles[name]
    del block_lists[name]
    broadcast(f"{name} has left the chat.")
    connection.close()
    print(f"{name} has disconnected.")

def start_server():
    try:
        while True:
            connection, address = server.accept()
            thread = threading.Thread(target=handle_client, args=(connection, address))
            thread.start()
    except KeyboardInterrupt:
        print("Shutting down the server...")
        server.close()

start_server()
