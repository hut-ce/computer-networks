import socket
import threading
import tkinter as tk
from tkinter import scrolledtext, messagebox

ip = "127.0.0.5"
port = 5050

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((ip, port))

name = input("Please enter your name: \n")
client.send(name.encode())

class ChatRoom:
    def __init__(self, root):
        self.root = root
        self.root.title("Chat Room")

        self.text_area = scrolledtext.ScrolledText(self.root, wrap=tk.WORD, state='disabled', height=20, width=50)
        self.text_area.grid(row=0, column=0, padx=10, pady=10, columnspan=2)

        self.message_entry = tk.Entry(self.root, width=40)
        self.message_entry.grid(row=1, column=0, padx=10, pady=10)

        self.send_button = tk.Button(self.root, text="Send", command=self.send_message)
        self.send_button.grid(row=1, column=1, padx=10, pady=10)

        threading.Thread(target=self.receive_messages, daemon=True).start()

    def send_message(self):
        message = self.message_entry.get()
        if message:
            client.send(message.encode('utf-8'))
            self.message_entry.delete(0, tk.END)

    def receive_messages(self):
        while True:
            try:
                message = client.recv(1024).decode()
                if not message:
                    break
                self.display_message(message)
            except ConnectionResetError:
                messagebox.showerror("Error", "Connection with server is lost!")
                break

    def display_message(self, message):
        self.text_area.configure(state='normal')
        self.text_area.insert(tk.END, message + "\n")
        self.text_area.configure(state='disabled')
        self.text_area.yview(tk.END)

root = tk.Tk()
chat_room = ChatRoom(root)
try:
    root.mainloop()
except KeyboardInterrupt:
    print("Closing the application.")
    client.close()
