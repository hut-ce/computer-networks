import socket
from utils import log_error, log_info

def main():
    try:
        IP = socket.gethostbyname(socket.gethostname())
        PORT = 5050
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect((IP, PORT))
        log_info("[*] Connected to server")

        # دریافت آرایه از کاربر
        array = input("Enter an array of numbers separated by spaces: ")
        client.sendall(array.encode('utf-8'))

        # دریافت نتیجه مرتب‌شده
        result = client.recv(1024).decode('utf-8')
        log_info(f"[*] Received result from server: {result}")
        print(result)

        client.close()
    except Exception as e:
        log_error(f"Client error: {str(e)}")

if __name__ == "__main__":
    main()
