import socket
import threading
import time
import logging
from utils import log_error, log_info

# تنظیمات لاگ
logging.basicConfig(filename='logs/server.log', level=logging.INFO, format='%(asctime)s - %(message)s')

# ارسال آرایه به SOها و دریافت نتایج
def handle_sorting(so_clients, array):
    results = []
    execution_times = []
    threads = []

    def send_and_receive(so_socket, idx):
        try:
            start_time = time.time()
            so_socket.sendall(str(array).encode('utf-8'))
            sorted_array = so_socket.recv(1024).decode('utf-8')
            end_time = time.time()

            results.append((idx, sorted_array))
            execution_times.append((idx, end_time - start_time))
        except Exception as e:
            log_error(f"Error in communication with SO {idx}: {str(e)}")

    for idx, so_client in enumerate(so_clients):
        thread = threading.Thread(target=send_and_receive, args=(so_client, idx))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    return results, execution_times

def main():
    try:
        IP =socket.gethostbyname(socket.gethostname())
        PORT = 5050
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.bind((IP, PORT))
        server.listen(4)
        log_info(" Server is running ")

        # انتظار برای اتصال کلاینت‌ها
        so_clients = []
        for _ in range(3):
            client_socket, addr = server.accept()
            log_info(f"[*] Connected to SO client {addr}")
            so_clients.append(client_socket)

        client_socket, addr = server.accept()
        log_info(f"[*] Connected to main client {addr}")

        # دریافت آرایه از کلاینت اصلی
        array = client_socket.recv(1024).decode('utf-8')
        array = list(map(int, array.strip('[]').split(',')))
        log_info(f"[*] Received array from main client: {array}")

        # ارسال آرایه به SOها و دریافت نتایج
        sorted_arrays, execution_times = handle_sorting(so_clients, array)

        # یافتن الگوریتم سریع‌تر
        fastest_algorithm = min(execution_times, key=lambda x: x[1])
        log_info(f"[*] Fastest algorithm: SO {fastest_algorithm[0]} with time {fastest_algorithm[1]}s")

        # ارسال نتایج به کلاینت اصلی
        result_message = f"Sorted arrays: {sorted_arrays}, Fastest algorithm: SO {fastest_algorithm[0]}"
        client_socket.sendall(result_message.encode('utf-8'))

        # بستن اتصالات
        client_socket.close()
        for so_client in so_clients:
            so_client.close()

    except Exception as e:
        log_error(f"Server error: {str(e)}")

if __name__ == "__main__":
    main()
