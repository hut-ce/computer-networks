import socket
from sorting_algorithms import bogo_sort
from utils import log_error, log_info

def main():
    try:
        IP = socket.gethostbyname(socket.gethostname())
        PORT = 5050
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect((IP, PORT))
        log_info("[*] Connected to server")

        # دریافت آرایه
        array = client.recv(1024).decode('utf-8')
        array = list(map(int, array.strip('[]').split(',')))

        # مرتب‌سازی
        sorted_array = bogo_sort(array)
        client.sendall(str(sorted_array).encode('utf-8'))
        log_info(f"[*] Sent sorted array: {sorted_array}")

        client.close()
    except Exception as e:
        log_error(f"SO1 error: {str(e)}")

if __name__ == "__main__":
    main()

